package com.serena.air

class TextAreaParser {
    boolean skipEmpty = true
    String delimiter = '='
    Closure onRepeatHandler
    List<Closure> handlers = []
    boolean detectComments = false

    //=====Setters=====

    public TextAreaParser delimiter(String delimiter) {
        this.delimiter = delimiter
        return this
    }
    public TextAreaParser onRepeat(Closure handler) {
        onRepeatHandler = handler
        return this
    }
    public TextAreaParser skipEmpty(boolean skipEmpty) {
        this.skipEmpty = skipEmpty
        return this
    }
    public TextAreaParser detectComments(boolean detectComments) {
        this.detectComments = detectComments
        return this
    }
    public TextAreaParser addParsedLineHandler(Closure handler) {
        handlers << handler
        return this
    }

    //=====Main methods=====

    public List<String> parseToList(String textAreaText) {
        List<String> result = []
        parseToCollection(textAreaText, result)
        return result
    }

    public void parseToCollection(String textAreaText, Collection collection) {
        parseTextAreaLines(textAreaText){ String line ->
            collection << line
        }
    }

    public Map<String, String> parseToMap(String textAreaText) {
        Map<String, String> result = [:]
        parseTextAreaLines(textAreaText){ String line ->
            if(!line.isEmpty()) {
                int delimPos = line.indexOf(delimiter)
                if (delimPos == -1) {
                    throw new StepFailedException("Could not parse parameter: $line. \nCould not find delimiter char '$delimiter'!")
                }
                String[] split = line.split(delimiter, 2)
                result[split[0]] = split[1]
            }
        }
        return result
    }

    public MultiMap<String, String> parseToMultiMap(String text) {
        assert delimiter != null
        MultiMap result = new MultiMap(new LinkedHashMap())
        parseTextAreaLines(text) {String fullLine ->
            if (skipEmpty && fullLine.isEmpty()) {
                return
            }

            String[] res = fullLine.split(delimiter, 2)
            String name
            String value
            if (res.length > 0) {
                name = res[0].trim()
            }
            if (res.length > 1) {
                value = res[1].trim()
            }

            boolean isRepeat = result.containsKey(name)
            if (isRepeat && onRepeatHandler != null) {
                callHandler(onRepeatHandler, name, value, fullLine, result)
            } else {
                handlers.each { handler ->
                    callHandler(handler, name, value, fullLine, result)
                }
            }
            result[name] << value
        }
        return result
    }

    private static void callHandler(Closure handler, String name, String value, String fullLine, MultiMap<String, String> resultMap) {
        Class[] handlerParams = handler.getParameterTypes()
        switch (handlerParams.size()) {
            case 2:
                handler(name, value)
                break;
            case 3:
                handler(name, value, fullLine)
                break;
            case 4:
                handler(name, value, fullLine, resultMap)
                break;
            default:
                throw new IllegalArgumentException('Handler closure should have 2, 3 or 4 parameters!')
        }
    }

    private void parseTextAreaLines(String textAreaText, Closure processor) {
        assert textAreaText != null : 'Provide some text to parse!'
        textAreaText.eachLine { fullLine ->
            String trimmed = fullLine.trim()
            if( !isComment(trimmed) ){
                processor(trimmed)
            }
        }
    }

    private boolean isComment(String line){
        if(detectComments){
            //Bash style comments
            if (line.startsWith('#')){
                return true
            }
            //Place for other checks ...
        }
        return false
    }
}