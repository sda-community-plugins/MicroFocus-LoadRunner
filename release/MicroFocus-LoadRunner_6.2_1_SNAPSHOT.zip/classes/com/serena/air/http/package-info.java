/**
 * This package contains helpers for apache http client lib.
 * This dependency is optional, so plugin must declare it itself.
 */
package com.serena.air.http;